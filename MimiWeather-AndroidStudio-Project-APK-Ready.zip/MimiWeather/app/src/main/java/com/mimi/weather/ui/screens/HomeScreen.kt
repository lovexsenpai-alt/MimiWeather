package com.mimi.weather.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mimi.weather.domain.*
import com.mimi.weather.ui.MimiMuted
import com.mimi.weather.ui.WeatherUiState
import com.mimi.weather.ui.components.*
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable fun HomeScreen(state:WeatherUiState, unit:String, reducedMotion:Boolean, onRetry:()->Unit, onSearch:()->Unit, onRefresh:()->Unit, onFavorite:()->Unit, isFavorite:Boolean){
    Box(Modifier.fillMaxSize()) {
        val kind=(state as? WeatherUiState.Success)?.data?.kind ?: WeatherKind.PARTLY_CLOUDY
        WeatherBackground(kind)
        when(state){
            WeatherUiState.Loading -> LoadingHome()
            is WeatherUiState.Error -> ErrorHome(state.message,onRetry,onSearch)
            is WeatherUiState.Success -> SuccessHome(state.data,unit,reducedMotion,onRefresh,onSearch,onFavorite,isFavorite)
        }
    }
}
@Composable private fun LoadingHome(){Column(Modifier.fillMaxSize().padding(22.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){CircularProgressIndicator();Spacer(Modifier.height(14.dp));Text("Mimi is looking at the sky…",color=MimiMuted)}}
@Composable private fun ErrorHome(msg:String,retry:()->Unit,search:()->Unit){Column(Modifier.fillMaxSize().padding(26.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Mascot(WeatherKind.FOG);Text(msg,fontSize=20.sp,fontWeight=FontWeight.SemiBold);Spacer(Modifier.height(16.dp));Button(onClick=retry){Text("Try Again")};TextButton(onClick=search){Text("Search City")}}}
@Composable private fun SuccessHome(d:WeatherSnapshot,unit:String,reducedMotion:Boolean,onRefresh:()->Unit,onSearch:()->Unit,onFavorite:()->Unit,isFavorite:Boolean){
    val temp=animateIntAsState(d.temperature,animationSpec=tween(700),label="temperature")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal=18.dp).padding(top=12.dp,bottom=100.dp)) {
        Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Cloud, null, tint=Color.White.copy(.95f));Text(" MIMI WEATHER",fontWeight=FontWeight.Bold,letterSpacing=1.8.sp,color=Color(0xFF32425E));Spacer(Modifier.weight(1f));IconButton(onClick=onSearch){Icon(Icons.Default.Search,"Search city",tint=Color(0xFF32425E))};IconButton(onClick=onRefresh){Icon(Icons.Default.Refresh,"Refresh",tint=Color(0xFF32425E))}}
        Spacer(Modifier.height(4.dp));Text("📍 ${d.place.name}, ${d.place.country}",fontSize=17.sp,fontWeight=FontWeight.SemiBold);Text(LocalDate.now().format(DateTimeFormatter.ofPattern("EEEE, MMMM d",Locale.ENGLISH)),color=MimiMuted)
        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) { Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.fillMaxWidth()){Text("Good ${if(LocalDate.now().atStartOfDay().hour<12)"morning" else "afternoon"} ✨",color=MimiMuted);Text("${displayTemp(temp.value,unit)}°",fontSize=72.sp,fontWeight=FontWeight.Light,color=Color(0xFF26334D),modifier=Modifier.semantics{contentDescription="Current temperature ${temp.value} degrees"});Text(condition(d.kind),fontSize=21.sp,fontWeight=FontWeight.SemiBold);Text("Feels like ${displayTemp(d.apparent,unit)}°",color=MimiMuted);Mascot(d.kind,reducedMotion);Text(mood(d.kind),fontSize=17.sp,fontWeight=FontWeight.Medium,color=Color(0xFF52627D));Row(verticalAlignment=Alignment.CenterVertically){Text("Updated ${((System.currentTimeMillis()-d.fetchedAt)/60000).coerceAtLeast(0)} min ago",fontSize=12.sp,color=MimiMuted);Spacer(Modifier.weight(1f));IconButton(onClick=onFavorite){Icon(if(isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,"Favorite city")}} } }
        Spacer(Modifier.height(18.dp));SectionTitle("Hourly forecast")
        LazyRow(horizontalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(vertical=8.dp)){items(d.hourly){h->GlassCard(Modifier.width(86.dp)){Text(h.time.substringAfter('T').take(5),fontSize=13.sp,color=MimiMuted);Spacer(Modifier.height(5.dp));Text(icon(h.kind),fontSize=23.sp);Text("${displayTemp(h.temp,unit)}°",fontSize=18.sp,fontWeight=FontWeight.SemiBold);Text("${h.rainChance}%",fontSize=11.sp,color=MimiMuted)}}}
        Spacer(Modifier.height(12.dp));SectionTitle("7-day forecast")
        GlassCard(Modifier.fillMaxWidth()){d.daily.forEachIndexed{idx,x->Row(Modifier.fillMaxWidth().padding(vertical=7.dp),verticalAlignment=Alignment.CenterVertically){Text(if(idx==0)"Today" else java.time.LocalDate.parse(x.date).format(DateTimeFormatter.ofPattern("EEE",Locale.ENGLISH)),Modifier.width(55.dp),fontWeight=if(idx==0)FontWeight.SemiBold else FontWeight.Normal);Text(icon(x.kind),fontSize=21.sp,modifier=Modifier.width(48.dp));Spacer(Modifier.weight(1f));Text("${displayTemp(x.max,unit)}°",fontWeight=FontWeight.SemiBold);Text("  ${displayTemp(x.min,unit)}°",color=MimiMuted)}}}
        if(d.kind==WeatherKind.HEAVY_RAIN || d.kind==WeatherKind.STORM){Spacer(Modifier.height(18.dp));GlassCard(Modifier.fillMaxWidth()){Text("⚠️  Weather Alert",fontWeight=FontWeight.Bold);Text(if(d.kind==WeatherKind.STORM)"Thunderstorms nearby — stay somewhere safe." else "Heavy rain expected — avoid unnecessary travel.",color=MimiMuted)}};Spacer(Modifier.height(18.dp));SectionTitle("Today’s mood");GlassCard(Modifier.fillMaxWidth()){Row(verticalAlignment=Alignment.CenterVertically){Text(icon(d.kind),fontSize=36.sp);Spacer(Modifier.width(12.dp));Column{Text(moodTitle(d.kind),fontWeight=FontWeight.SemiBold,fontSize=18.sp);Text(mood(d.kind),color=MimiMuted)}}}
        Spacer(Modifier.height(18.dp));SectionTitle("Details");DetailsGrid(d)
    }
}
@Composable private fun DetailsGrid(d:WeatherSnapshot){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Detail("Humidity","${d.humidity}%",Icons.Default.WaterDrop);Detail("Wind","${d.wind} km/h",Icons.Default.Air)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Detail("UV Index","${d.uv}",Icons.Default.WbSunny);Detail("Pressure","${d.pressure} hPa",Icons.Default.Speed)};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){Detail("Visibility","${"%.1f".format(d.visibilityKm)} km",Icons.Default.Visibility);Detail("Sunrise / sunset","${d.sunrise} / ${d.sunset}",Icons.Default.WbTwilight)}}}
@Composable private fun Detail(label:String,value:String,icon:androidx.compose.ui.graphics.vector.ImageVector){GlassCard(Modifier.weight(1f)){Icon(icon,null,tint=Color(0xFF7C90D8));Spacer(Modifier.height(8.dp));Text(label,fontSize=12.sp,color=MimiMuted);Text(value,fontWeight=FontWeight.SemiBold,fontSize=15.sp)}}
@Composable private fun SectionTitle(s:String){Text(s,fontSize=19.sp,fontWeight=FontWeight.SemiBold,color=Color(0xFF30405B))}
private fun icon(k:WeatherKind)=when(k){WeatherKind.SUNNY->"☀️";WeatherKind.PARTLY_CLOUDY->"🌤️";WeatherKind.CLOUDY->"☁️";WeatherKind.RAIN->"🌧️";WeatherKind.HEAVY_RAIN->"🌧️";WeatherKind.STORM->"⛈️";WeatherKind.FOG->"🌫️";WeatherKind.SNOW->"❄️";WeatherKind.HOT->"☀️";WeatherKind.NIGHT->"🌙"}
private fun displayTemp(v:Int,unit:String)=if(unit=="F") (v*9/5+32) else v
private fun moodTitle(k:WeatherKind)=when(k){WeatherKind.SUNNY->"Sunny Little Adventure";WeatherKind.RAIN->"Cozy Rain Day";WeatherKind.STORM->"Stay Safe, Mimi";WeatherKind.SNOW->"Snowy Cozy Day";WeatherKind.NIGHT->"Dreamy Night";else->"Cozy Cloud Day"}
