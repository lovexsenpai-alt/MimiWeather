package com.mimi.weather.ui.screens
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.mimi.weather.ui.components.GlassCard

@Composable fun SettingsScreen(unit:String,theme:String,animations:Boolean,notifications:Boolean,onBack:()->Unit,setUnit:(String)->Unit,setTheme:(String)->Unit,setAnimations:(Boolean)->Unit,setNotifications:(Boolean)->Unit){Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(18.dp)){Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){IconButton(onBack){Icon(Icons.Default.ArrowBack,"Back")};Text("Settings",style=MaterialTheme.typography.titleLarge)};Spacer(Modifier.height(14.dp));SettingCard("Temperature"){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(unit=="C",{setUnit("C")},{Text("°C")});FilterChip(unit=="F",{setUnit("F")},{Text("°F")})}};SettingCard("Theme"){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("System","Light","Dark").forEach{v->FilterChip(theme==v,{setTheme(v)},{Text(v)})}}};SettingToggle("Animations","Keep Mimi’s subtle motion on",animations,setAnimations);SettingToggle("Notifications","Weather alerts",notifications,setNotifications);Spacer(Modifier.height(16.dp));Text("About Mimi Weather",style=MaterialTheme.typography.titleMedium);Text("A soft little window into the sky.\nBuilt with Kotlin, Jetpack Compose and Open-Meteo.",modifier=Modifier.padding(top=8.dp))}}
@Composable private fun SettingCard(title:String,content:@Composable RowScope.()->Unit){GlassCard(Modifier.fillMaxWidth().padding(bottom=12.dp)){Text(title,style=MaterialTheme.typography.titleMedium);Spacer(Modifier.height(10.dp));content()}}
@Composable private fun SettingToggle(title:String,sub:String,value:Boolean,onChange:(Boolean)->Unit){GlassCard(Modifier.fillMaxWidth().padding(bottom=12.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(title,fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold);Text(sub,color=com.mimi.weather.ui.MimiMuted,fontSize=13.sp)};Switch(value,onChange)}}}
