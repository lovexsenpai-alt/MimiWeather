package com.mimi.weather.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.mimi.weather.domain.WeatherKind

@Composable fun Mascot(kind: WeatherKind, reducedMotion:Boolean=false, modifier:Modifier=Modifier){
    val t= if(reducedMotion) 0f else rememberInfiniteTransition(label="mascot").let { tr -> val v by tr.animateFloat(0f,1f,infiniteRepeatable(tween(2800,easing=FastOutSlowInEasing),RepeatMode.Reverse),label="float"); v }
    Canvas(modifier.size(210.dp)) { val bob=(t-.5f)*10; when(kind){ WeatherKind.SUNNY,WeatherKind.HOT -> fox(bob,kind==WeatherKind.HOT); WeatherKind.PARTLY_CLOUDY,WeatherKind.CLOUDY -> catOrBear(bob,kind); WeatherKind.RAIN,WeatherKind.HEAVY_RAIN -> rainBear(bob,kind==WeatherKind.HEAVY_RAIN); WeatherKind.STORM -> dragon(bob); WeatherKind.FOG -> panda(bob); WeatherKind.SNOW -> penguin(bob); WeatherKind.NIGHT -> moonCat(bob) } }
}
private fun DrawScope.face(c:Offset, r:Float, fill:Color){ drawCircle(fill,r,c); drawCircle(Color.White.copy(.25f),r,c,style=Stroke(1.5f)); drawCircle(Color(0xFF26334D),r*.10f,Offset(c.x-r*.28f,c.y-r*.06f)); drawCircle(Color(0xFF26334D),r*.10f,Offset(c.x+r*.28f,c.y-r*.06f)); drawCircle(Color.White,r*.035f,Offset(c.x-r*.30f,c.y-r*.10f)); drawCircle(Color.White,r*.035f,Offset(c.x+r*.26f,c.y-r*.10f)); drawCircle(Color(0xFFE99A9A),r*.10f,Offset(c.x-r*.52f,c.y+r*.18f)); drawCircle(Color(0xFFE99A9A),r*.10f,Offset(c.x+r*.52f,c.y+r*.18f)) }
private fun DrawScope.fox(b:Float,hot:Boolean){ val c=Offset(size.width/2,size.height*.54f+b); drawCircle(Color.White.copy(.4f),85f,Offset(c.x,c.y+30)); drawCircle(Color(0xFFF0A46E),65f,c); face(c,65f,Color(0xFFF0A46E)); drawPath(androidx.compose.ui.graphics.Path().apply{moveTo(c.x-52,c.y-45);lineTo(c.x-62,c.y-92);lineTo(c.x-25,c.y-65);close()},Color(0xFFF0A46E)); drawPath(androidx.compose.ui.graphics.Path().apply{moveTo(c.x+52,c.y-45);lineTo(c.x+62,c.y-92);lineTo(c.x+25,c.y-65);close()},Color(0xFFF0A46E)); if(hot){drawCircle(Color(0xFFB7D6E8),27f,Offset(c.x+83,c.y+10));drawLine(Color(0xFF9BB8C9),Offset(c.x+75,c.y+10),Offset(c.x+50,c.y+4),4f)}else{drawRoundRect(Color(0xFF27334D),Offset(c.x-50,c.y-75),Offset(c.x+50,c.y-55),5f);drawLine(Color(0xFF27334D),Offset(c.x,c.y-75),Offset(c.x,c.y-55),5f)} }
private fun DrawScope.catOrBear(b:Float,k:WeatherKind){ val c=Offset(size.width/2,size.height*.55f+b); drawCircle(Color.White.copy(.55f),70f,Offset(c.x,c.y+35)); face(c,62f,if(k==WeatherKind.CLOUDY) Color(0xFFB8AFA8) else Color(0xFFE7D6C7)); drawCircle(Color(0xFFE7D6C7),24f,Offset(c.x-45,c.y-47));drawCircle(Color(0xFFE7D6C7),24f,Offset(c.x+45,c.y-47)); if(k==WeatherKind.CLOUDY){drawLine(Color(0xFF6D5E5B),Offset(c.x-9,c.y+12),Offset(c.x+9,c.y+12),4f)} }
private fun DrawScope.rainBear(b:Float,heavy:Boolean){ val c=Offset(size.width/2-12,size.height*.55f+b); face(c,60f,Color(0xFFC9B8AE)); drawCircle(Color(0xFF27334D),14f,Offset(c.x-31,c.y-4));drawCircle(Color(0xFF27334D),14f,Offset(c.x+31,c.y-4)); drawArc(Color.White.copy(.65f),190f,160f,false,Offset(c.x+5,c.y-5),80f,style=Stroke(5f)); drawArc(Color(0xFFFFD96A),180f,180f,false,Offset(c.x,c.y+2),95f,style=Stroke(7f)); if(heavy) drawRoundRect(Color(0xFFFFD96A),Offset(c.x-65,c.y+35),Size(130f,75f),cornerRadius=androidx.compose.ui.geometry.CornerRadius(28f)) }
private fun DrawScope.dragon(b:Float){ val c=Offset(size.width/2,size.height*.55f+b); face(c,62f,Color(0xFF9BC9B0)); drawCircle(Color(0xFFE6B7D7),14f,Offset(c.x-45,c.y-40));drawCircle(Color(0xFFE6B7D7),14f,Offset(c.x+45,c.y-40)); drawLine(Color(0xFFF8D97A),Offset(c.x,c.y-10),Offset(c.x+15,c.y+15),4f) }
private fun DrawScope.panda(b:Float){ val c=Offset(size.width/2,size.height*.55f+b); face(c,62f,Color(0xFFE5E1DE));drawCircle(Color(0xFF384258),18f,Offset(c.x-38,c.y-8));drawCircle(Color(0xFF384258),18f,Offset(c.x+38,c.y-8));drawCircle(Color(0xFFBFD4E1),75f,Offset(c.x,c.y+40)) }
private fun DrawScope.penguin(b:Float){ val c=Offset(size.width/2,size.height*.55f+b);drawOval(Color(0xFF35425C),Offset(c.x-58,c.y-65),Size(116f,140f));drawOval(Color.White,Offset(c.x-42,c.y-35),Size(84f,105f));drawCircle(Color(0xFFFFD66B),8f,Offset(c.x-22,c.y+5));drawCircle(Color(0xFFFFD66B),8f,Offset(c.x+22,c.y+5));drawArc(Color(0xFFFFD66B),200f,140f,false,Offset(c.x,c.y+10),18f,style=Stroke(6f))}
private fun DrawScope.moonCat(b:Float){ val c=Offset(size.width/2,size.height*.55f+b);drawCircle(Color(0xFFFFE7A3),72f,Offset(c.x+30,c.y-40));drawCircle(Color(0xFF2B3154),72f,Offset(c.x+55,c.y-65));face(c,55f,Color(0xFF8B91C2));drawCircle(Color.White.copy(.7f),4f,Offset(c.x-70,c.y-65));drawCircle(Color.White.copy(.7f),3f,Offset(c.x+70,c.y-10))}
