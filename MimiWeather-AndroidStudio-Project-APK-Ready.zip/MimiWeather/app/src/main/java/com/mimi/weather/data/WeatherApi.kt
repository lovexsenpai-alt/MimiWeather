package com.mimi.weather.data

import retrofit2.http.GET
import retrofit2.http.Query

data class GeoResult(val id: Long, val name: String, val latitude: Double, val longitude: Double, val country: String?, val admin1: String?)
data class GeoResponse(val results: List<GeoResult>?)

data class CurrentWeather(
    @com.google.gson.annotations.SerializedName("temperature_2m") val temperature: Double,
    @com.google.gson.annotations.SerializedName("relative_humidity_2m") val humidity: Int,
    @com.google.gson.annotations.SerializedName("apparent_temperature") val apparent: Double,
    @com.google.gson.annotations.SerializedName("is_day") val isDay: Int,
    @com.google.gson.annotations.SerializedName("weather_code") val weatherCode: Int,
    @com.google.gson.annotations.SerializedName("wind_speed_10m") val windSpeed: Double,
    @com.google.gson.annotations.SerializedName("surface_pressure") val pressure: Double,
    @com.google.gson.annotations.SerializedName("visibility") val visibility: Double,
    @com.google.gson.annotations.SerializedName("uv_index") val uvIndex: Double
)
data class HourlyWeather(
    val time: List<String>,
    @com.google.gson.annotations.SerializedName("temperature_2m") val temperature: List<Double>,
    @com.google.gson.annotations.SerializedName("precipitation_probability") val precipitationProbability: List<Int>,
    @com.google.gson.annotations.SerializedName("weather_code") val weatherCode: List<Int>
)
data class DailyWeather(
    val time: List<String>,
    @com.google.gson.annotations.SerializedName("weather_code") val weatherCode: List<Int>,
    @com.google.gson.annotations.SerializedName("temperature_2m_max") val max: List<Double>,
    @com.google.gson.annotations.SerializedName("temperature_2m_min") val min: List<Double>,
    val sunrise: List<String>, val sunset: List<String>
)
data class WeatherResponse(val current: CurrentWeather, val hourly: HourlyWeather, val daily: DailyWeather)

interface WeatherApi {
    @GET("v1/forecast") suspend fun forecast(
        @Query("latitude") lat: Double, @Query("longitude") lon: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m,surface_pressure,visibility,uv_index",
        @Query("hourly") hourly: String = "temperature_2m,precipitation_probability,weather_code",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset",
        @Query("forecast_days") days: Int = 7, @Query("timezone") timezone: String = "auto"
    ): WeatherResponse

    @GET("https://geocoding-api.open-meteo.com/v1/search") suspend fun geocode(@Query("name") name: String, @Query("count") count: Int = 10, @Query("language") language: String = "en", @Query("format") format: String = "json"): GeoResponse
}
