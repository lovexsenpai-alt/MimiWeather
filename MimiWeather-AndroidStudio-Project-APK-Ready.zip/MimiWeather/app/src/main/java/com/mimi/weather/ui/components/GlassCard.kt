package com.mimi.weather.ui.components
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
@Composable fun GlassCard(modifier:Modifier=Modifier, content:@Composable ColumnScope.()->Unit){ Column(modifier.shadow(10.dp,RoundedCornerShape(26.dp)).background(Color.White.copy(.54f),RoundedCornerShape(26.dp)).border(1.dp,Color.White.copy(.7f),RoundedCornerShape(26.dp)).padding(18.dp),content=content) }
