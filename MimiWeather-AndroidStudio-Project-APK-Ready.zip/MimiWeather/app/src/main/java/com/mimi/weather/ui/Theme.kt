package com.mimi.weather.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val MimiInk = Color(0xFF23304A)
val MimiMuted = Color(0xFF71809B)
val MimiSky = Color(0xFFF2FAFF)
val MimiGlass = Color(0xBFFFFFFF)
val MimiAccent = Color(0xFF7A91F5)

private val LightScheme = lightColorScheme(primary=MimiAccent, onPrimary=Color.White, background=MimiSky, surface=Color.White, onSurface=MimiInk)
private val DarkScheme = darkColorScheme(primary=Color(0xFFAAB8FF), background=Color(0xFF11172B), surface=Color(0xFF1B2340), onSurface=Color(0xFFE9EEFF), onBackground=Color(0xFFE9EEFF))
@Composable fun MimiTheme(dark:Boolean, content:@Composable()->Unit) { MaterialTheme(colorScheme=if(dark) DarkScheme else LightScheme, typography=Typography(bodyLarge=TextStyle(fontSize=16.sp), titleLarge=TextStyle(fontSize=24.sp,fontWeight=FontWeight.SemiBold), headlineLarge=TextStyle(fontSize=58.sp,fontWeight=FontWeight.Light)), content=content) }
