package com.mimi.weather

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.mimi.weather.location.LocationProvider
import com.mimi.weather.ui.MimiApp

class MainActivity : ComponentActivity() {
    private lateinit var locationProvider: LocationProvider
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); enableEdgeToEdge()
        locationProvider = LocationProvider(this)
        setContent { MimiApp(locationProvider) }
    }
}
