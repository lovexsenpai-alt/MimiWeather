package com.mimi.weather.domain

enum class WeatherKind { SUNNY, PARTLY_CLOUDY, CLOUDY, RAIN, HEAVY_RAIN, STORM, FOG, SNOW, HOT, NIGHT }
data class Place(val name: String, val region: String?, val country: String, val lat: Double, val lon: Double)
data class WeatherSnapshot(
    val place: Place, val temperature: Int, val apparent: Int, val humidity: Int, val wind: Int,
    val pressure: Int, val visibilityKm: Double, val uv: Double, val kind: WeatherKind,
    val code: Int, val hourly: List<Hour>, val daily: List<Day>, val sunrise: String, val sunset: String,
    val fetchedAt: Long
)
data class Hour(val time: String, val temp: Int, val rainChance: Int, val kind: WeatherKind)
data class Day(val date: String, val max: Int, val min: Int, val kind: WeatherKind)

fun weatherKind(code: Int, isDay: Boolean, temp: Double): WeatherKind = when {
    !isDay -> WeatherKind.NIGHT
    temp >= 35 -> WeatherKind.HOT
    code == 0 -> WeatherKind.SUNNY
    code in 1..3 -> if (code == 1) WeatherKind.PARTLY_CLOUDY else WeatherKind.CLOUDY
    code in 45..48 -> WeatherKind.FOG
    code in 51..67 || code in 80..82 -> if (code in 65..67 || code == 82) WeatherKind.HEAVY_RAIN else WeatherKind.RAIN
    code in 71..77 || code in 85..86 -> WeatherKind.SNOW
    code >= 95 -> WeatherKind.STORM
    else -> WeatherKind.CLOUDY
}
fun condition(kind: WeatherKind) = when(kind) {
    WeatherKind.SUNNY -> "Sunny"; WeatherKind.PARTLY_CLOUDY -> "Partly Cloudy"; WeatherKind.CLOUDY -> "Mostly Cloudy"; WeatherKind.RAIN -> "Rain"; WeatherKind.HEAVY_RAIN -> "Heavy Rain"; WeatherKind.STORM -> "Thunderstorm"; WeatherKind.FOG -> "Fog"; WeatherKind.SNOW -> "Snow"; WeatherKind.HOT -> "Hot"; WeatherKind.NIGHT -> "Clear Night"
}
fun mood(kind: WeatherKind) = when(kind) {
    WeatherKind.SUNNY -> "Perfect day for a little adventure ☀️"; WeatherKind.RAIN, WeatherKind.HEAVY_RAIN -> "Grab your umbrella, little explorer ☔"; WeatherKind.SNOW -> "A soft, snowy day calls for something cozy 🧣"; WeatherKind.STORM -> "Best to stay somewhere safe today ⛈️"; WeatherKind.HOT -> "Keep cool and take it easy today 🧊"; WeatherKind.NIGHT -> "The sky is sleepy. Mimi says goodnight ✨"; WeatherKind.FOG -> "A misty little world outside today 🌫️"; else -> "Looks like a cozy cloudy day ☁️"
}
