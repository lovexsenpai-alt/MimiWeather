package com.mimi.weather.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mimi.weather.data.WeatherRepository
import com.mimi.weather.domain.*
import com.mimi.weather.location.LocationProvider
import com.mimi.weather.preferences.PreferencesRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.google.gson.Gson

sealed interface WeatherUiState { data object Loading: WeatherUiState; data class Success(val data: WeatherSnapshot): WeatherUiState; data class Error(val message: String): WeatherUiState }
class WeatherViewModel(private val repo: WeatherRepository, private val prefs: PreferencesRepository, private val location: LocationProvider): ViewModel() {
    private val _state = MutableStateFlow<WeatherUiState>(WeatherUiState.Loading); val state: StateFlow<WeatherUiState> = _state.asStateFlow()
    private val _search = MutableStateFlow<List<Place>>(emptyList()); val searchResults = _search.asStateFlow()
    val unit = prefs.unit.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "C")
    val theme = prefs.theme.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), "System")
    val animations = prefs.animations.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val notifications = prefs.notifications.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), true)
    val favorites = prefs.favorites.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())
    val manualPlace = prefs.manualPlace.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)
    private var currentPlace: Place? = null
    fun load(place: Place) {
        currentPlace = place
        viewModelScope.launch {
            prefs.setManualPlace("${place.name}|${place.region ?: ""}|${place.country}|${place.lat}|${place.lon}")
        }
        refresh()
    }
    fun refresh() { val p=currentPlace ?: return; viewModelScope.launch {
        runCatching { Gson().fromJson(prefs.cachedWeather.first(), WeatherSnapshot::class.java) }
            .getOrNull()
            ?.takeIf { it.place.lat == p.lat && it.place.lon == p.lon }
            ?.let { _state.value = WeatherUiState.Success(it) }
        if (_state.value !is WeatherUiState.Success) _state.value = WeatherUiState.Loading
        runCatching { repo.weather(p.lat, p.lon) }.onSuccess { r ->
val hs=r.hourly.time.indices.map { i -> Hour(r.hourly.time[i], r.hourly.temperature[i].roundToInt(), r.hourly.precipitationProbability.getOrElse(i){0}, weatherKind(r.hourly.weatherCode[i], true, r.hourly.temperature[i])) }.take(24)
        val ds=r.daily.time.indices.map { i -> Day(r.daily.time[i], r.daily.max[i].roundToInt(), r.daily.min[i].roundToInt(), weatherKind(r.daily.weatherCode[i], true, r.daily.max[i])) }
        val snapshot=WeatherSnapshot(p,r.current.temperature.roundToInt(),r.current.apparent.roundToInt(),r.current.humidity,r.current.windSpeed.roundToInt(),r.current.pressure.roundToInt(),r.current.visibility/1000.0,r.current.uvIndex,weatherKind(r.current.weatherCode,r.current.isDay==1,r.current.temperature),r.current.weatherCode,hs,ds,formatTime(r.daily.sunrise.firstOrNull()),formatTime(r.daily.sunset.firstOrNull()),System.currentTimeMillis()); _state.value=WeatherUiState.Success(snapshot); prefs.setCachedWeather(Gson().toJson(snapshot))
    }.onFailure { _state.value=WeatherUiState.Error("Oops! Mimi can't see the sky right now.") } } }
    fun search(q:String) { if(q.trim().length<2){_search.value=emptyList();return}; viewModelScope.launch { runCatching { repo.search(q.trim()) }.onSuccess { _search.value=it.map { x -> Place(x.name,x.admin1,x.country ?: "",x.latitude,x.longitude) } }.onFailure { _search.value=emptyList() } } }
    fun setUnit(v:String)=viewModelScope.launch{prefs.setUnit(v)}
    fun setTheme(v:String)=viewModelScope.launch{prefs.setTheme(v)}
    fun setAnimations(v:Boolean)=viewModelScope.launch{prefs.setAnimations(v)}
    fun setNotifications(v:Boolean)=viewModelScope.launch{prefs.setNotifications(v)}
    fun toggleFavorite(p:Place){ viewModelScope.launch { prefs.setFavorite(key(p), !(favorites.value.contains(key(p)))) } }
    private fun key(p:Place)="${p.name}|${p.lat}|${p.lon}|${p.country}"
    fun favoritePlace(key:String):Place?=key.split("|").takeIf{it.size>=4}?.let{Place(it[0],null,it[3],it[1].toDoubleOrNull()?:0.0,it[2].toDoubleOrNull()?:0.0)}
    private fun formatTime(s:String?)=s?.substringAfter('T')?.take(5) ?: "—"
    private fun Double.roundToInt()=kotlin.math.round(this).toInt()
    companion object { fun factory(c:Context)=object:ViewModelProvider.Factory { override fun <T:ViewModel> create(modelClass:Class<T>):T = WeatherViewModel(WeatherRepository(),PreferencesRepository(c),LocationProvider(c)) as T } }
}
