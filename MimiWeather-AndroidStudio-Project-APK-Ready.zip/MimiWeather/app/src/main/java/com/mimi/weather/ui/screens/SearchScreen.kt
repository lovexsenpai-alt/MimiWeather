package com.mimi.weather.ui.screens
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.font.FontWeight
import com.mimi.weather.domain.Place
import com.mimi.weather.ui.MimiMuted
import com.mimi.weather.ui.components.GlassCard
import kotlinx.coroutines.delay

@Composable fun SearchScreen(results:List<Place>, onBack:()->Unit, onQuery:(String)->Unit, onSelect:(Place)->Unit){var q by remember{mutableStateOf("")};LaunchedEffect(q){delay(250);onQuery(q)};Column(Modifier.fillMaxSize().padding(18.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(onBack){Icon(Icons.Default.ArrowBack,"Back")};Text("Find a place",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.weight(1f))};Spacer(Modifier.height(12.dp));OutlinedTextField(value=q,onValueChange={q=it},modifier=Modifier.fillMaxWidth(),singleLine=true,leadingIcon={Icon(Icons.Default.Search,null)},placeholder={Text("Search city worldwide")},shape=MaterialTheme.shapes.extraLarge);Spacer(Modifier.height(14.dp));if(q.length<2){Text("Try Patna, London, Tokyo…",color=MimiMuted)}else if(results.isEmpty()){Column(Modifier.fillMaxWidth().padding(top=50.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("🌤️",fontSize=42.sp);Text("Mimi couldn't find that place.",fontWeight=FontWeight.SemiBold)}}else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(results){p->GlassCard(Modifier.fillMaxWidth().clickable{onSelect(p)}){Text(p.name,fontWeight=FontWeight.SemiBold);Text(listOfNotNull(p.region,p.country).joinToString(", "),color=MimiMuted,fontSize=13.sp)}}}}}
