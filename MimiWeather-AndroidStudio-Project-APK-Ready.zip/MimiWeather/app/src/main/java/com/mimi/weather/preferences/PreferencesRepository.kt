package com.mimi.weather.preferences

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore("mimi_preferences")
class PreferencesRepository(private val context: Context) {
    private val c = context.dataStore
    val unit: Flow<String> = c.data.map { it[Keys.UNIT] ?: "C" }
    val theme: Flow<String> = c.data.map { it[Keys.THEME] ?: "System" }
    val animations: Flow<Boolean> = c.data.map { it[Keys.ANIMATIONS] ?: true }
    val notifications: Flow<Boolean> = c.data.map { it[Keys.NOTIFICATIONS] ?: true }
    val manualPlace: Flow<String?> = c.data.map { it[Keys.MANUAL_PLACE] }
    val cachedWeather: Flow<String?> = c.data.map { it[Keys.CACHED_WEATHER] }
    suspend fun setUnit(v: String) { c.edit { it[Keys.UNIT] = v } }
    suspend fun setTheme(v: String) { c.edit { it[Keys.THEME] = v } }
    suspend fun setAnimations(v: Boolean) { c.edit { it[Keys.ANIMATIONS] = v } }
    suspend fun setNotifications(v: Boolean) { c.edit { it[Keys.NOTIFICATIONS] = v } }
    val favorites: Flow<Set<String>> = c.data.map { it[Keys.FAVORITES] ?: emptySet() }
    suspend fun setFavorite(key: String, add: Boolean) { c.edit { val old=it[Keys.FAVORITES] ?: emptySet(); it[Keys.FAVORITES] = if(add) old + key else old - key } }
    suspend fun setCachedWeather(v:String) { c.edit { it[Keys.CACHED_WEATHER]=v } }
    suspend fun setManualPlace(v: String?) { c.edit { if (v == null) it.remove(Keys.MANUAL_PLACE) else it[Keys.MANUAL_PLACE] = v } }
    private object Keys { val CACHED_WEATHER=stringPreferencesKey("cached_weather"); val FAVORITES=stringSetPreferencesKey("favorites"); val UNIT=stringPreferencesKey("unit"); val THEME=stringPreferencesKey("theme"); val ANIMATIONS=booleanPreferencesKey("animations"); val NOTIFICATIONS=booleanPreferencesKey("notifications"); val MANUAL_PLACE=stringPreferencesKey("manual_place") }
}
