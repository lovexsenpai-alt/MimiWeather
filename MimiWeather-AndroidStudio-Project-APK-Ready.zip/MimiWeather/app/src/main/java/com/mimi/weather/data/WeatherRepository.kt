package com.mimi.weather.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class WeatherRepository(private val api: WeatherApi = Retrofit.Builder().baseUrl("https://api.open-meteo.com/").addConverterFactory(GsonConverterFactory.create()).build().create(WeatherApi::class.java)) {
    suspend fun weather(lat: Double, lon: Double) = withContext(Dispatchers.IO) { api.forecast(lat, lon) }
    suspend fun search(city: String) = withContext(Dispatchers.IO) { api.geocode(city).results.orEmpty() }
}
