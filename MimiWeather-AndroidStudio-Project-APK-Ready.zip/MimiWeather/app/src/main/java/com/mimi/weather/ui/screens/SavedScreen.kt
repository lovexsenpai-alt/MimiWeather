package com.mimi.weather.ui.screens
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mimi.weather.domain.Place
import com.mimi.weather.ui.MimiMuted
import com.mimi.weather.ui.components.GlassCard

@Composable fun SavedScreen(favorites:Set<String>,resolve:(String)->Place?,onSelect:(Place)->Unit){Column(Modifier.fillMaxSize().padding(18.dp)){Text("Saved places",style=MaterialTheme.typography.titleLarge);Spacer(Modifier.height(14.dp));if(favorites.isEmpty())Column(Modifier.fillMaxWidth().padding(top=80.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Favorite,null,tint=MimiMuted,modifier=Modifier.size(42.dp));Text("Your favorite skies will appear here.",color=MimiMuted)}else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(favorites.toList()){k->resolve(k)?.let{p->GlassCard(Modifier.fillMaxWidth().clickable{onSelect(p)}){Text(p.name,fontWeight=androidx.compose.ui.text.font.FontWeight.SemiBold);Text(p.country,color=MimiMuted)}}}}}}
