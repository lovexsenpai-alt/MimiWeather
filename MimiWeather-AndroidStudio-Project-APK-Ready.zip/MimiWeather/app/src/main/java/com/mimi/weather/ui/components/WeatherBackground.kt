package com.mimi.weather.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.mimi.weather.domain.WeatherKind
import kotlin.random.Random

@Composable fun WeatherBackground(kind:WeatherKind, modifier:Modifier=Modifier) {
    val infinite=rememberInfiniteTransition(label="sky"); val drift by infinite.animateFloat(0f,1f,infiniteRepeatable(tween(12000),RepeatMode.Reverse),label="drift")
    Canvas(modifier.fillMaxSize()) { drawSky(kind); when(kind){ WeatherKind.RAIN,WeatherKind.HEAVY_RAIN,WeatherKind.STORM -> rain(drift); WeatherKind.SNOW -> snow(drift); WeatherKind.SUNNY,WeatherKind.HOT -> sun(drift); WeatherKind.NIGHT -> stars(drift); else -> clouds(drift) } }
}
private fun DrawScope.drawSky(k:WeatherKind){ val (a,b)=when(k){WeatherKind.NIGHT->Color(0xFF141A35) to Color(0xFF51477A); WeatherKind.STORM->Color(0xFF53617E) to Color(0xFF9AA6C4); WeatherKind.SNOW->Color(0xFFEAF7FF) to Color(0xFFC7D9F1); WeatherKind.RAIN,WeatherKind.HEAVY_RAIN->Color(0xFFD7E8F5) to Color(0xFF9DB6CF); WeatherKind.SUNNY,WeatherKind.HOT->Color(0xFFFFF1D5) to Color(0xFFDDF4FF); else->Color(0xFFE9F8FF) to Color(0xFFDDE7FF)}; drawRect(Brush.verticalGradient(listOf(a,b))) }
private fun DrawScope.clouds(t:Float){ repeat(4){i-> val x=((i*180)+(t*100))% (size.width+180)-90; val y=100+i*85f; drawCircle(Color.White.copy(.32f),48f,Offset(x,y)); drawCircle(Color.White.copy(.28f),65f,Offset(x+45,y+8)) } }
private fun DrawScope.rain(t:Float){ val r=Random(9); repeat(48){ val x=r.nextFloat()*size.width; val y=((r.nextFloat()*size.height+t*220)%size.height); drawLine(Color.White.copy(.38f),Offset(x,y),Offset(x-8,y+26),2f) } }
private fun DrawScope.snow(t:Float){ val r=Random(7); repeat(38){ val x=r.nextFloat()*size.width; val y=((r.nextFloat()*size.height+t*80)%size.height); drawCircle(Color.White.copy(.7f),r.nextFloat()*4+1,Offset(x,y)) } }
private fun DrawScope.sun(t:Float){ val c=Offset(size.width*.78f, size.height*.16f); repeat(5){i-> drawCircle(Color.White.copy(.06f),90f+i*35,c) }; drawCircle(Color(0xFFFFE6A6).copy(.7f),55f,c) }
private fun DrawScope.stars(t:Float){ val r=Random(4); repeat(32){ val x=r.nextFloat()*size.width; val y=r.nextFloat()*size.height*.65f; drawCircle(Color.White.copy(.3f+.2f*r.nextFloat()),r.nextFloat()*2+1,Offset(x,y)) } }
