package com.mimi.weather.ui

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.LaunchedEffect
import androidx.activity.compose.BackHandler
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.mimi.weather.domain.Place
import com.mimi.weather.location.LocationProvider
import com.mimi.weather.ui.components.Mascot
import com.mimi.weather.ui.components.WeatherBackground
import com.mimi.weather.ui.screens.*

@Composable fun MimiApp(locationProvider:LocationProvider){
    val context=LocalContext.current; val vm:WeatherViewModel=viewModel(factory=WeatherViewModel.factory(context)); val locationRequested=remember{mutableStateOf(false)}; val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){ locationRequested.value=true } val state by vm.state.collectAsState(); val results by vm.searchResults.collectAsState(); val unit by vm.unit.collectAsState(); val theme by vm.theme.collectAsState(); val animations by vm.animations.collectAsState(); val notifications by vm.notifications.collectAsState(); val favorites by vm.favorites.collectAsState()
    val dark=when(theme){"Dark"->true;"Light"->false;else->androidx.compose.foundation.isSystemInDarkTheme()}; MimiTheme(dark){
        var selectedTab by rememberSaveable{mutableIntStateOf(0)}; var showSearch by rememberSaveable{mutableStateOf(false)}; var onboarding by rememberSaveable{mutableStateOf(vm.manualPlace.value == null)}
        LaunchedEffect(Unit){ while(true){ kotlinx.coroutines.delay(600_000); if(vm.state.value is WeatherUiState.Success) vm.refresh() } }
        LaunchedEffect(vm.manualPlace.value){ vm.manualPlace.value?.let { val a=it.split("|"); if(a.size>=5 && vm.state.value is WeatherUiState.Loading) vm.load(Place(a[0],a[1].ifBlank{null},a[2],a[3].toDoubleOrNull()?:25.5941,a[4].toDoubleOrNull()?:85.1376); onboarding=false } }
        LaunchedEffect(locationRequested.value){ if(locationRequested.value){ val c=locationProvider.current(); if(c!=null) vm.load(Place("Your location",null,"",c.lat,c.lon)); else vm.load(Place("Patna",null,"India",25.5941,85.1376)) } }
        if(onboarding){Onboarding(onLocation={launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION));onboarding=false},onSearch={onboarding=false;showSearch=true})} else {
            AnimatedContent(selectedTab,transitionSpec={fadeIn(tween(250)) togetherWith fadeOut(tween(180))},label="tab"){tab->when(tab){0->HomeScreen(state,unit,!animations,vm::refresh,{showSearch=true},vm::refresh, { (state as? WeatherUiState.Success)?.data?.let(vm::toggleFavorite) }, (state as? WeatherUiState.Success)?.data?.let{p->favorites.contains("${p.place.name}|${p.place.lat}|${p.place.lon}|${p.place.country}")}==true);1->SearchScreen(results,{selectedTab=0}){vm.search(it)}{vm.load(it);showSearch=false;selectedTab=0};2->SavedScreen(favorites,vm::favoritePlace){vm.load(it);selectedTab=0};3->SettingsScreen(unit,theme,animations,notifications,{selectedTab=0},vm::setUnit,vm::setTheme,vm::setAnimations,vm::setNotifications)}}
            if(showSearch){BackHandler{showSearch=false}; SearchScreen(results,{showSearch=false}){vm.search(it)}{vm.load(it);showSearch=false;selectedTab=0}}
            NavigationBar(Modifier.padding(12.dp).navigationBarsPadding(),containerColor=Color.White.copy(if(dark).12f else .68f),tonalElevation=0.dp){listOf(Icons.Default.Home to "Home",Icons.Default.Search to "Search",Icons.Default.Favorite to "Saved",Icons.Default.Settings to "Settings").forEachIndexed{i,p->NavigationBarItem(selectedTab==i,onClick={selectedTab=i},icon={Icon(p.first,null)},label={Text(p.second)})}}
        }
    }
}
@Composable private fun Onboarding(onLocation:()->Unit,onSearch:()->Unit){Box(Modifier.fillMaxSize()){WeatherBackground(com.mimi.weather.domain.WeatherKind.PARTLY_CLOUDY);Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Mascot(com.mimi.weather.domain.WeatherKind.PARTLY_CLOUDY);Text("Mimi Weather",style=MaterialTheme.typography.headlineMedium);Text("Where should we show your weather?",color=MimiMuted);Spacer(Modifier.height(24.dp));Button(onClick=onLocation,modifier=Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.MyLocation,null);Spacer(Modifier.width(8.dp));Text("Use my location")};OutlinedButton(onClick=onSearch,modifier=Modifier.fillMaxWidth().height(54.dp)){Icon(Icons.Default.Search,null);Spacer(Modifier.width(8.dp));Text("Search city")};Text("You can change this anytime in Settings.",color=MimiMuted,fontSize=12.sp,modifier=Modifier.padding(top=14.dp))}}}
