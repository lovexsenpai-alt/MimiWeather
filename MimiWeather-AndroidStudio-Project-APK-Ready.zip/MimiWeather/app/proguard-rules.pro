# Mimi Weather intentionally uses no custom obfuscation rules.
