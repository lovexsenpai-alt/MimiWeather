# Mimi Weather

A mobile-first, anime-inspired weather app built with Kotlin, Jetpack Compose, Material 3 and Open-Meteo.

## Build on a phone or in GitHub

This project is configured so it does **not require the Gradle wrapper** to be present for the GitHub build. The included GitHub Actions workflow installs Gradle 8.10.2 and builds the APK automatically.

### Easiest phone-only method

1. Upload this project to a GitHub repository from your phone.
2. Open the repository's **Actions** tab.
3. Select **Build Mimi Weather APK**.
4. Tap **Run workflow**.
5. Wait for the build to finish.
6. Open the completed workflow run and download the artifact named **mimi-weather-debug-apk**.
7. Extract the artifact and install `app-debug.apk` on your Android phone.

The APK is a debug build and is directly installable on a device for testing.

### Local build

With Android SDK + JDK 17 + Gradle 8.10.2 installed:

```bash
gradle assembleDebug
gradle assembleRelease
```

Debug APK:
`app/build/outputs/apk/debug/app-debug.apk`

Release APK:
`app/build/outputs/apk/release/app-release-unsigned.apk`

## Features

- Open-Meteo current, hourly and 7-day weather
- Open-Meteo worldwide geocoding search
- Current-location weather with runtime permission
- Saved cities using DataStore
- Celsius/Fahrenheit
- System/Light/Dark theme
- Reduced-motion preference
- Weather-reactive animated environment
- Original Canvas-drawn Mimi mascots
- Offline-friendly cached weather display
- Material 3 / Compose UI
- Responsive mobile layout and accessibility semantics
